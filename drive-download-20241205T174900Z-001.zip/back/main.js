document.getElementById("submitButton").addEventListener("click", async (event) => {
    event.preventDefault();  // Impede o envio do formulário

    // Captura os dados dos inputs
    const idUsuario = document.getElementById("idUsuario").value;
    const idNutricionista = document.getElementById("idNutricionista").value;

    const formData = new FormData(document.getElementById("menuForm"));
    const cardapio = {
        usuario: { idUsuario: parseInt(idUsuario, 10) }, // Convertendo para número
        nutricionista: { idNutricionista: parseInt(idNutricionista, 10) }, // Convertendo para número
        cafeDaManha: {
            opcao1: formData.get("cafeOpcao1"),
            opcao2: formData.get("cafeOpcao2"),
            opcao3: formData.get("cafeOpcao3"),
        },
        almoco: {
            opcao1: formData.get("almocoOpcao1"),
            opcao2: formData.get("almocoOpcao2"),
            opcao3: formData.get("almocoOpcao3"),
        },
        jantar: {
            opcao1: formData.get("jantarOpcao1"),
            opcao2: formData.get("jantarOpcao2"),
            opcao3: formData.get("jantarOpcao3"),
        },
    };

    try {
        // Faz o envio ao backend
        const response = await fetch("http://localhost:8080/cardapios", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(cardapio),
        });

        // Verifica se a resposta foi bem-sucedida
        if (response.ok) {
            const responseBody = await response.text(); // Obtemos o corpo da resposta como texto

            if (responseBody) {
                // Verifica se o corpo não está vazio antes de tentar parsear
                try {
                    const jsonResponse = JSON.parse(responseBody); // Faz o parse do JSON
                    alert("Cardápio salvo com sucesso!");
                    document.getElementById("menuForm").reset();
                } catch (jsonError) {
                    alert("A resposta não está em formato JSON válido.");
                    console.error("Erro ao parsear a resposta:", jsonError);
                }
            } else {
                alert("Cardápio salvo com sucesso, mas sem resposta adicional.");
                document.getElementById("menuForm").reset();
            }
        } else {
            // Se a resposta não foi ok (erro no backend)
            const errorData = await response.text();
            const errorMessage = errorData ? JSON.parse(errorData).message : response.statusText;
            alert(`Erro: ${errorMessage}`);
        }
    } catch (error) {
        console.error("Erro:", error);
        alert("Erro ao salvar o cardápio.");
    }
});
