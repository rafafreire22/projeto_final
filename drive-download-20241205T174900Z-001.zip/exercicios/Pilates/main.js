// Função para o botão play
const playButton = document.getElementById('play-button');
const video = document.getElementById('video');
const videoThumbnail = document.getElementById('video-thumbnail');
const closeButton = document.getElementById('close-button');

// Ao clicar no botão Play, o vídeo será exibido e começa a rodar
playButton.addEventListener('click', function() {
    // Esconde a imagem de miniatura e mostra o vídeo
    videoThumbnail.style.display = 'none';
    video.style.display = 'block';
    closeButton.style.display = 'block'; // Exibe o botão "X" para fechar
    video.play();
});

// Função para o botão "X"
closeButton.addEventListener('click', function() {
    // Pausa o vídeo, esconde o botão "X" e a área do vídeo
    video.pause();
    video.currentTime = 0; // Retorna o vídeo para o início
    video.style.display = 'none';
    videoThumbnail.style.display = 'block'; // Exibe novamente a miniatura
    closeButton.style.display = 'none'; // Esconde o botão "X"
});
