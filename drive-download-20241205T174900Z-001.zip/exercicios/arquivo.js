// Função para controlar a exibição e animação do menu hamburguer
function menuOnClick() {
    // Adiciona ou remove a classe 'change' no menu, alterando seu estilo
    document.getElementById("menu-bar").classList.toggle("change");
    
    // Adiciona ou remove a classe 'change' no menu de navegação
    document.getElementById("nav").classList.toggle("change");
    
    // Adiciona ou remove a classe 'change-bg', possivelmente para alterar o fundo do menu
    document.getElementById("menu-bg").classList.toggle("change-bg");
}

// Função que redireciona para a página de exercícios ao clicar no botão 'botaoPilates'
function botao() {
    document.getElementById('botaoPilates').addEventListener('click', function() {
        // Redireciona o usuário para a página de exercícios Pilates
        window.location.href = 'exercicios-pilates.html';
    });
}

// Função para mostrar um alerta quando o botão 1 for clicado
document.getElementById('btn1').addEventListener('click', function() {
    // Exibe um alerta informando sobre os benefícios do alongamento
    alert('O alongamento ajuda a preparar os músculos antes da atividade física.');
});

// Função para mostrar um alerta quando o botão 2 for clicado
document.getElementById('btn2').addEventListener('click', function() {
    // Exibe um alerta informando sobre o treino funcional
    alert('O treino funcional trabalha o corpo de forma dinâmica e completa.');
});

// Função para mostrar um alerta quando o botão 3 for clicado
document.getElementById('btn3').addEventListener('click', function() {
    // Exibe um alerta sobre os benefícios do Pilates
    alert('O Pilates é ótimo para melhorar a flexibilidade e a postura.');
});
