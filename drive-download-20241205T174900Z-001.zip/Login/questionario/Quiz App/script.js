document.getElementById("start-quiz-btn").addEventListener("click", () => {  // Adiciona um evento de clique no botão com o ID 'start-quiz-btn'
    // Redireciona para a página do quiz
    window.location.href = "./quiz/quiz.html"; // Redireciona o usuário para a página do quiz quando o botão for clicado
});
